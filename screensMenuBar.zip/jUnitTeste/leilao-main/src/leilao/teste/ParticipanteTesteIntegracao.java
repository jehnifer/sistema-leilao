package leilao.teste;

import javax.persistence.EntityManager;

import org.junit.Test;

import leilao.entidade.Participante;
import leilao.jpa.util.JPAUtil;

public class ParticipanteTesteIntegracao {

	@Test
	public void deveAdicionarParticipanteNoBanco() {
//		new JPAUtil();
//		EntityManager em = JPAUtil.getEntityManager();
//		em.getTransaction().begin();
//		em.persist(new Participante("Fantasma2", "04034403", "12/05/1995"));
//		em.getTransaction().commit();
//		em.close();
	}
}
